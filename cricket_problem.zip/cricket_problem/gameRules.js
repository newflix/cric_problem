class GameRules{
    constructor(){
        const instance = this.constructor.instance;
        if(instance){
            return instance;
        }

        this.numOfOvers = 0;
        this.numOfBallsPerOver = 6;
        this.wideRun = 1;
        this.noBallRun = 1;
        this.constructor.instance = this;
    }
}

module.exports = GameRules;
