const TeamScoreCard = require('./teamScoreCard');

class CricketTeam{
    constructor(teamName, numOfPlayers, playerNames){
        this.teamName = teamName;
        this.numOfPlayers = numOfPlayers;
        this.playerNames = playerNames;
        this.scoreCard = new TeamScoreCard(this);
    }

    updateScoreCard(currentPlayerName, ballResult){
        let ballResultStr = new String(ballResult);
        let currentPlayer = null;
        switch(ballResult){
            case '0':
                this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                this.scoreCard.totalBalls+=1;

                if(this.scoreCard.totalBalls === 6){
                    this.scoreCard.totalOvers+=1;
                    this.scoreCard.totalBalls = 0;
                    currentPlayer = this.scoreCard.currentPlayer;
                    this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                    this.scoreCard.updateOneDownPlayer(currentPlayer);
                }
                break;
            case '1': 
                this.scoreCard.getPlayerScoreCard(currentPlayerName).runs++;
                this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                this.scoreCard.totalScore+=1;
                this.scoreCard.totalBalls+=1;

                currentPlayer = this.scoreCard.currentPlayer;
                this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                this.scoreCard.updateOneDownPlayer(currentPlayer);

                if(this.scoreCard.totalBalls === 6){
                    this.scoreCard.totalOvers+=1;
                    this.scoreCard.totalBalls = 0;
                    currentPlayer = this.scoreCard.currentPlayer;
                    this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                    this.scoreCard.updateOneDownPlayer(currentPlayer);
                }

                break;
            case '2':
                this.scoreCard.getPlayerScoreCard(currentPlayerName).runs+=2;
                this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                this.scoreCard.totalScore+=2;
                this.scoreCard.totalBalls+=1;

                if(this.scoreCard.totalBalls === 6){
                    this.scoreCard.totalOvers+=1;
                    this.scoreCard.totalBalls = 0;
                    currentPlayer = this.scoreCard.currentPlayer;
                    this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                    this.scoreCard.updateOneDownPlayer(currentPlayer);
                }
                break;
            case '3':
                this.scoreCard.getPlayerScoreCard(currentPlayerName).runs+=3;
                this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                this.scoreCard.totalScore+=3;
                this.scoreCard.totalBalls+=1;

                currentPlayer = this.scoreCard.currentPlayer;
                this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                this.scoreCard.updateOneDownPlayer(currentPlayer);

                if(this.scoreCard.totalBalls === 6){
                    this.scoreCard.totalOvers+=1;
                    this.scoreCard.totalBalls = 0;
                    currentPlayer = this.scoreCard.currentPlayer;
                    this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                    this.scoreCard.updateOneDownPlayer(currentPlayer);
                }

                break;
            case '4':
                this.scoreCard.getPlayerScoreCard(currentPlayerName).runs+=4;
                this.scoreCard.getPlayerScoreCard(currentPlayerName).fours+=1;
                this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                this.scoreCard.totalScore+=4;
                this.scoreCard.totalBalls+=1;

                if(this.scoreCard.totalBalls === 6){
                    this.scoreCard.totalOvers+=1;
                    this.scoreCard.totalBalls = 0;
                    currentPlayer = this.scoreCard.currentPlayer;
                    this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                    this.scoreCard.updateOneDownPlayer(currentPlayer);
                }

                break;
            case '6':
                    this.scoreCard.getPlayerScoreCard(currentPlayerName).runs+=6;
                    this.scoreCard.getPlayerScoreCard(currentPlayerName).sixes+=1;
                    this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed++;
                    this.scoreCard.totalScore+=6;
                    this.scoreCard.totalBalls+=1;
    
                    if(this.scoreCard.totalBalls === 6){
                        this.scoreCard.totalOvers+=1;
                        this.scoreCard.totalBalls = 0;
                        currentPlayer = this.scoreCard.currentPlayer;
                        this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                        this.scoreCard.updateOneDownPlayer(currentPlayer);
                    }
                    break;
                case 'wd':
                    this.scoreCard.totalScore+=1;
                    this.scoreCard.wds+=1;
                    this.scoreCard.extras+=1;
                    break;
                case 'nb':
                    this.scoreCard.totalScore+=1;
                    this.scoreCard.nbs+=1;
                    this.scoreCard.extras+=1;
                    break;
                case 'w':
                    this.scoreCard.getPlayerScoreCard(currentPlayerName).isOut = true;
                if(!this.scoreCard.isAllOut){
                    this.scoreCard.getPlayerScoreCard(currentPlayerName).ballsPlayed+=1;
                    this.scoreCard.totalWickets+=1;
                    this.scoreCard.totalBalls+=1;

                    if(this.scoreCard.totalWickets === this.scoreCard.playerScores.length-1){
                        this.scoreCard.isAllOut = true;
                        break;
                    }

                    currentPlayer = this.scoreCard.getNextPlayer();

                    this.scoreCard.updateCurrentPlayer(currentPlayer);

                    if(this.scoreCard.totalBalls === 6){
                        this.scoreCard.totalOvers+=1;
                        this.scoreCard.totalBalls = 0;
                        let oneDownPlayer = this.scoreCard.oneDownPlayer;
                        this.scoreCard.updateOneDownPlayer(currentPlayer);
                        this.scoreCard.updateCurrentPlayer(oneDownPlayer);
                    }
                    break;

                }

                case (ballResultStr.match(/wd/) || {}).input:
                    let eRun = 0;
                    console.log('Here i am..');
                    if(ballResult.length === 3){
                        for(let c of ballResult){
                            if(c.charCodeAt() > 47 && c.charCodeAt()< 58){
                                eRun = c.charCodeAt()-48;
                                this.updateScoreCard(this.scoreCard.currentPlayer, eRun);
                            }
                        }

                        for(let i = 0; i < eRun; ++i){
                            this.updateScoreCard(this.scoreCard.currentPlayer,'wd');
                        }

                        if(eRun%2 === 0){
                            //strike rotate
                            let currentPlayer = this.scoreCard.getCurrentPlayer();
                            this.scoreCard.updateCurrentPlayer(this.scoreCard.oneDownPlayer);
                            this.scoreCard.updateOneDownPlayer(currentPlayer);
                        }
                        break;
                    }
        }
    }
}

module.exports = CricketTeam;