class PlayerScoreCard{
    constructor(playerName){
        this.playerName = playerName;
        this.fours = 0;
        this.sixes = 0;
        this.runs = 0;
        this.ballsPlayed = 0;
        this.isOut = false;
    }
}

module.exports = PlayerScoreCard;