const CricketAdminBoard = require('./cricAdminBoard');
const CricketTeam = require('./circketTeam');
const prompt = require('prompt-sync')();

let cricBoard = new CricketAdminBoard();

cricBoard.numOfBallsPerOver = 6;
cricBoard.wideBallRun = 1;
cricBoard.noBallRun = 1;

const numOfPlayers = prompt('Enter no of players in each team: ');

const numOfOvers = prompt('Enter number of overs:');
cricBoard.numOfOvers = numOfOvers;

const battingOrder1 = prompt('Enter batting order for teamA:').split(' ');
let teamA = new CricketTeam('TeamA',numOfPlayers,battingOrder1);
calculateScorecard(teamA);

const battingOrder2 = prompt('Enter batting order for teamB:').split(' ');
let teamB = new CricketTeam('TeamB',numOfPlayers,battingOrder2);
calculateScorecard(teamB);

printResult(teamA,teamB);

function printResult(teamA,teamB){
    if(teamA.scoreCard.totalScore > teamB.scoreCard.totalScore){
        let winByRuns = teamA.scoreCard.totalScore - teamB.scoreCard.totalScore;
        console.log(`TeamA won by ${winByRuns} runs`);
    }
    else if(teamA.scoreCard.totalScore < teamB.scoreCard.totalScore){
        let winByWickets = teamB.scoreCard.playerScores.length-teamB.scoreCard.totalWickets;
        console.log(`TeamB won by ${winByWickets} wickets`);
    }
    else{
        console.log('Match Tied !! Super Over !!')
    }
}

function calculateScorecard(teamA){
        
    for(let i = 1; i <= numOfOvers; ++i){
        const over = 'over'+ i + ': ';
        const overResult = prompt(over).split(' ');

        for(let j = 0; j < overResult.length; ++j){
            if(teamA.scoreCard.isAllOut){
                break;
            }
            let currentPlayer = teamA.scoreCard.getCurrentPlayer();
            teamA.updateScoreCard(currentPlayer,overResult[j]);
        }

        let currentPlayer = teamA.scoreCard.getCurrentPlayer();
        let oneDownPlayer = teamA.scoreCard.getOneDownPlayer();

        let topDisplayLine = `${teamA.teamName}
        --------------------------------------------------
        Player Name     Score     4s     6s     Balls
        --------------------------------------------------`;

        const tab4 = '            ';
        const tab3 = '        ';
        let data = topDisplayLine;
        for(let playerScore of teamA.scoreCard.playerScores){
            let playerScoreDisplayLine = '';
            if((currentPlayer === playerScore.playerName ||
                oneDownPlayer === playerScore.playerName) && !playerScore.isOut){
                    playerScoreDisplayLine = `
                    ${playerScore.playerName}*${tab4}${playerScore.runs}${tab3}${playerScore.fours}${tab3}${playerScore.sixes}${tab3}${playerScore.ballsPlayed}
                    `;

            }
            else{
                playerScoreDisplayLine = `
                ${playerScore.playerName}${tab4}${playerScore.runs}${tab3}${playerScore.fours}${tab3}${playerScore.sixes}${tab3}${playerScore.ballsPlayed}
                `;
            }
            data = data+playerScoreDisplayLine;
        }
        let totalScoreDisplayLine = `
        Total: ${teamA.scoreCard.totalScore}/${teamA.scoreCard.totalWickets}
        `;
        data = data+totalScoreDisplayLine;
        let oversDisplayLine = `Overs: ${teamA.scoreCard.totalOvers}.${teamA.scoreCard.totalBalls}`;
        data = data + oversDisplayLine;

        console.log(data);
        if(teamA.scoreCard.isAllOut){
            break;
        }
    }
}