const PlayerScoreCard = require('./playerScorecard');

class TeamScoreCard{
    constructor(team){
        this.teamName = team.teamName;
        this.playerScores = [];
        this.totalScore = 0;
        this.totalWickets = 0;
        this.totalOvers = 0;
        this.totalBalls = 0;
        this.nbs = 0;
        this.wds = 0;
        this.extras = 0;
        this.isAllOut = false;
        this.currentPlayer = team.playerNames[0];
        this.oneDownPlayer = team.playerNames[1];
        this.nextPlayer = null;

        for(let i = 0; i < team.numOfPlayers; ++i){
            this.playerScores.push(new PlayerScoreCard(team.playerNames[i]));
         }
    }

    getPlayerScoreCard(playerName){
        for(let scoreCard of this.playerScores){
            if(scoreCard.playerName === playerName){
                return scoreCard;
            }
        }

        return null;
    }

    getNextPlayer(){
        if(this.totalWickets+1 < this.playerScores.length){
            this.nextPlayer = this.playerScores[this.totalWickets + 1].playerName;
            return this.nextPlayer;
        }

        return null;
    }
    getCurrentPlayer(){
        return this.currentPlayer;
    }
    updateCurrentPlayer(playerName){
        this.currentPlayer = playerName;
    }

    updateOneDownPlayer(playerName){
        this.oneDownPlayer = playerName;
    }
}

module.exports = TeamScoreCard;
