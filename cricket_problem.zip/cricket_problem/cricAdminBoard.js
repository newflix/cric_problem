const GameRules = require('./gameRules');

class CricketAdminBoard{
    constructor(){
        const instance = this.constructor.instance;
        if(instance){
            return instance;
        }
        this.gameRules = new GameRules();
        this.constructor.instance = this;
    }

    set numOfOvers(overs){
        this.gameRules.numOfOvers = overs;
    }

    set wideBallRun(wdRun){
        this.gameRules.wideRun = wdRun;
    }

    set noBallRun(nbRun){
        this.gameRules.noBallRun = nbRun;
    }

    set numOfBallsPerOver(numOfBalls){
        this.gameRules.numOfBallsPerOver = numOfBalls;
    }
}

module.exports = CricketAdminBoard;